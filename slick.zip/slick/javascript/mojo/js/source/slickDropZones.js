(function () { 
    if (!mstrmojo.plugins.slick) {
        mstrmojo.plugins.slick = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.vi.models.CustomVisDropZones",
        "mstrmojo.array"
    );

    mstrmojo.plugins.slick.slickDropZones = mstrmojo.declare(
        mstrmojo.vi.models.CustomVisDropZones,
        null,
        {
            scriptClass: "mstrmojo.plugins.slick.slickDropZones",
            cssClass: "slickdropzones",
            getCustomDropZones: function getCustomDropZones(){
 },
            shouldAllowObjectsInDropZone: function shouldAllowObjectsInDropZone(zone, dragObjects, idx, edge, context) {
    
 
 
  
  
  
     
 








},
            getActionsForObjectsDropped: function getActionsForObjectsDropped(zone, droppedObjects, idx, replaceObject, extras) {
    
 
 
  
  
  
     
 








},
            getActionsForObjectsRemoved: function getActionsForObjectsRemoved(zone, objects) { 
     
  
  
   
   
   
      
 








},
            getDropZoneContextMenuItems: function getDropZoneContextMenuItems(cfg, zone, object, el) {
    
 
 
  
  
  
     
 








}
})}());
//@ sourceURL=slickDropZones.js