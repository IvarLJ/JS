(function () { 
    if (!mstrmojo.plugins.slick) {
        mstrmojo.plugins.slick = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.CustomVisBase",
        "mstrmojo.models.template.DataInterface",
        "mstrmojo.vi.models.editors.CustomVisEditorModel"
    );

    mstrmojo.plugins.slick.slick = mstrmojo.declare(
        mstrmojo.CustomVisBase,
        null,
        {
            scriptClass: "mstrmojo.plugins.slick.slick",
            cssClass: "slick",
            errorMessage: "Either there is not enough data to display the visualization or the visualization configuration is incomplete.",
            errorDetails: "This visualization requires one or more attributes and one metric.",
            externalLibraries: [{url:"https://cdn.jsdelivr.net/npm/jquery@3.3.0/dist/jquery.min.js"},{url:"https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"}],
            useRichTooltip: false,
            reuseDOMNode: false,
            plot:function(){
$('head').append('<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/kenwheeler/slick@1.8.1/slick/slick-theme.css">');
var borderDiv = document.createElement("div");
borderDiv.setAttribute("class","borderDiv");

var DIModel = new mstrmojo.models.template.DataInterface(this.model.data);
var cardList = DIModel.getColumnHeaderData()[0].es;

var mainDiv = document.createElement("div");
//mainDiv.setAttribute("data-slick","'slidesToShow':4, 'slidesToScroll':4");
mainDiv.setAttribute("class","Carousel");

for (var i = 0, len = cardList.length; i < len; i++) {
  var cardDiv = document.createElement("div");
  var titleDiv = document.createElement("H3");
  var title = document.createTextNode(cardList[i].n);
  titleDiv.appendChild(title);
  cardDiv.appendChild(titleDiv);
  mainDiv.appendChild(cardDiv);                            
}

borderDiv.appendChild(mainDiv);

//debugger;


this.domNode.appendChild(borderDiv); 

/*$('.Carousel').slick({
		infinite: true,
		slidesToShow: 3,
		slidesToScroll: 3
		});*/


         





}})}());
//@ sourceURL=slick.js