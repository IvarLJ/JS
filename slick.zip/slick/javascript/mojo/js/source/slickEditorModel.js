(function () { 
    if (!mstrmojo.plugins.slick) {
        mstrmojo.plugins.slick = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.vi.models.editors.CustomVisEditorModel",
        "mstrmojo.array"
    );

    mstrmojo.plugins.slick.slickEditorModel = mstrmojo.declare(
        mstrmojo.vi.models.editors.CustomVisEditorModel,
        null,
        {
            scriptClass: "mstrmojo.plugins.slick.slickEditorModel",
            cssClass: "slickeditormodel",
            getCustomProperty: function getCustomProperty(){










}
})}());
//@ sourceURL=slickEditorModel.js